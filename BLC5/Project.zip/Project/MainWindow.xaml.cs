﻿using Microsoft.Win32;
using Newtonsoft.Json;
using Project.Model;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace Project
{
    public partial class MainWindow : Window
    {
        private Root data;
        private List<CheckBox> scoreCheckBoxes = new List<CheckBox>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoadJsonFile(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*";
            if (openFileDialog.ShowDialog() == true)
            {
                string json = File.ReadAllText(openFileDialog.FileName);
                data = JsonConvert.DeserializeObject<Root>(json);

                if (data?.Courses != null)
                {
                    CourseComboBox.ItemsSource = data.Courses;
                    CourseComboBox.DisplayMemberPath = "CourseID";
                }
                else
                {
                    MessageBox.Show("Failed to load data from JSON file.");
                }
            }
        }

        private void CourseComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (CourseComboBox.SelectedItem is Course selectedCourse)
            {
                ScoreCheckBoxPanel.Visibility = Visibility.Visible;

                StudentDataGrid.Columns.Clear();
                ScoreCheckBoxPanel.Children.Clear();
                scoreCheckBoxes.Clear();

                StudentDataGrid.Columns.Add(new DataGridTextColumn
                {
                    Header = "Student ID",
                    Binding = new Binding("StudentID"),
                    Width = new DataGridLength(1, DataGridLengthUnitType.Star),
                    IsReadOnly = true
                });

                StudentDataGrid.Columns.Add(new DataGridTextColumn
                {
                    Header = "Name",
                    Binding = new Binding("Name"),
                    Width = new DataGridLength(2, DataGridLengthUnitType.Star),
                    IsReadOnly = true
                });

                if (selectedCourse.Students != null && selectedCourse.Students.Count > 0)
                {
                    var scoreKeys = selectedCourse.Students.First().Scores.Keys;
                    foreach (var key in scoreKeys)
                    {
                        CheckBox checkBox = new CheckBox
                        {
                            Content = key,
                            IsChecked = true,
                            Tag = key
                        };
                        checkBox.Checked += ScoreCheckBox_Checked;
                        checkBox.Unchecked += ScoreCheckBox_Unchecked;
                        ScoreCheckBoxPanel.Children.Add(checkBox);
                        scoreCheckBoxes.Add(checkBox);
                    }
                }

                CheckBox checkAllCheckBox = new CheckBox
                {
                    Content = "Choose All",
                    IsChecked = true
                };
                checkAllCheckBox.Checked += CheckAllCheckBox_Checked;
                checkAllCheckBox.Unchecked += CheckAllCheckBox_Unchecked;
                ScoreCheckBoxPanel.Children.Insert(0, checkAllCheckBox);

                StudentDataGrid.ItemsSource = selectedCourse.Students;

                UpdateDataGrid();
            }
            else
            {
                ScoreCheckBoxPanel.Visibility = Visibility.Collapsed;
            }
        }

        private void UpdateDataGrid()
        {
            if (CourseComboBox.SelectedItem is Course selectedCourse)
            {
                StudentDataGrid.Columns.Clear();

                StudentDataGrid.Columns.Add(new DataGridTextColumn
                {
                    Header = "Student ID",
                    Binding = new Binding("StudentID"),
                    Width = new DataGridLength(1, DataGridLengthUnitType.Star),
                    IsReadOnly = true
                });

                StudentDataGrid.Columns.Add(new DataGridTextColumn
                {
                    Header = "Name",
                    Binding = new Binding("Name"),
                    Width = new DataGridLength(2, DataGridLengthUnitType.Star),
                    IsReadOnly = true
                });

                if (selectedCourse.Students != null)
                {
                    foreach (var checkBox in scoreCheckBoxes)
                    {
                        if (checkBox.IsChecked == true)
                        {
                            string key = checkBox.Tag.ToString();
                            StudentDataGrid.Columns.Add(new DataGridTextColumn
                            {
                                Header = key,
                                Binding = new Binding($"Scores[{key}]"),
                                Width = new DataGridLength(1, DataGridLengthUnitType.Star)
                            });
                        }
                    }

                   
                        CalculateGPA(selectedCourse);
                        StudentDataGrid.Columns.Add(new DataGridTextColumn
                        {
                            Header = "GPA",
                            Binding = new Binding("GPA"),
                            Width = new DataGridLength(1, DataGridLengthUnitType.Star),
                            IsReadOnly = true
                        });
                    

                    StudentDataGrid.ItemsSource = selectedCourse.Students;
                }
            }
        }

        private void CalculateGPA(Course course)
        {
            if (course.Students != null)
            {
                foreach (var student in course.Students)
                {
                    if (student.Scores.Count > 0)
                    {
                        student.GPA = student.Scores.Values.Average();
                    }
                    else
                    {
                        student.GPA = 0; // Đảm bảo GPA có giá trị mặc định nếu không có điểm
                    }
                }
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (data != null && CourseComboBox.SelectedItem is Course selectedCourse)
            {
                if (StudentDataGrid.SelectedItem is Student selectedStudent)
                {
                    // Cập nhật thông tin từ TextBox vào đối tượng Student
                    selectedStudent.Name = StudentNameTextBox.Text;

                    CalculateGPA(selectedCourse); // Tính lại GPA nếu cần

                    // Lưu dữ liệu vào tệp JSON
                    string json = JsonConvert.SerializeObject(data, Formatting.Indented);
                    File.WriteAllText("Course.json", json);
                    MessageBox.Show("Data saved to Course.json");

                    // Cập nhật lại DataGrid để hiển thị thông tin mới nhất
                    UpdateDataGrid();
                }
            }
        }


        private void ScoreCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            UpdateDataGrid();
        }

        private void ScoreCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateDataGrid();
        }

        private void CheckAllCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            foreach (var checkBox in scoreCheckBoxes)
            {
                checkBox.IsChecked = true;
            }
            UpdateDataGrid();
        }

        private void CheckAllCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            foreach (var checkBox in scoreCheckBoxes)
            {
                checkBox.IsChecked = false;
            }
            UpdateDataGrid();
        }

        private void StudentDataGrid_CellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (e.EditAction == DataGridEditAction.Commit)
            {
                var student = e.Row.DataContext as Student;
                if (student != null)
                {
                    if (CourseComboBox.SelectedItem is Course selectedCourse)
                    {
                        CalculateGPA(selectedCourse);
                        UpdateDataGrid(); // Refresh DataGrid to show updated GPA
                    }
                }
            }
        }

        private void StudentDataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (StudentDataGrid.SelectedItem is Student selectedStudent)
            {
                StudentNameTextBox.Text = selectedStudent.Name;
                StudentIDTextBox.Text = selectedStudent.StudentID.ToString();
            }
        }

    }
}