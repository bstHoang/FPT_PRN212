﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.Model
{
    public class Score
    {
        public Dictionary<string, double> Scores { get; set; } = new Dictionary<string, double>();
    }
}
